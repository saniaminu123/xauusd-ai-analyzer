const API_BASE = "http://localhost:8000";
let timeframe = "1M";

const $ = id => document.getElementById(id);
const money = n => n == null ? "—" : Number(n).toLocaleString(undefined,{maximumFractionDigits:5});

document.querySelectorAll("#tf button").forEach(b => b.onclick = () => {
  document.querySelectorAll("#tf button").forEach(x=>x.classList.remove("active"));
  b.classList.add("active");
  timeframe = b.dataset.tf;
});

async function runAnalysis(){
  const symbol = $("symbol").value;
  $("run").textContent = "ANALYZING…";
  try{
    const res = await fetch(`${API_BASE}/api/analysis/${symbol}?timeframe=${timeframe}`);
    const data = await res.json();
    if(!res.ok) throw new Error(data.detail || "Analysis failed");
    render(data);
  }catch(e){
    $("status").textContent = "DATA ERROR";
    $("reason").textContent = e.message;
  }finally{
    $("run").textContent = "RUN FULL ANALYSIS";
  }
}

function render(d){
  $("name").textContent = d.symbol;
  $("price").textContent = `${money(d.price)} • ${d.timeframe}`;
  $("bias").textContent = d.bias + " BIAS";
  $("status").textContent = d.status.replace("_"," ");
  $("confidence").textContent = d.confidence + "%";
  $("bar").style.width = d.confidence + "%";
  $("zoneText").textContent = `${money(d.interest_low)} – ${money(d.interest_high)}`;
  $("entry").textContent = money(d.entry);
  $("sl").textContent = money(d.sl);
  $("tp1").textContent = money(d.tp1);
  $("tp2").textContent = money(d.tp2);
  $("tp3").textContent = money(d.tp3);
  $("rr").textContent = d.rr ? "1 : " + d.rr : "—";
  $("direction").textContent = d.bias === "NEUTRAL" ? "(WAIT)" : `(${d.bias === "BULLISH" ? "BUY" : "SELL"} SETUP)`;
  $("reason").textContent = d.status === "WAIT" ? "Price has not reached the Interest Zone or structure is not ready." :
    d.status === "IN_ZONE" ? "Price is inside the Interest Zone. Wait for confirmation." :
    d.status === "CONFIRMED" ? "Confirmation conditions passed. Review the Trade Plan before execution." :
    "Setup invalidated.";

  $("reasons").innerHTML = d.reasons.map(x=>`<li>${x}</li>`).join("");

  const labels = {
    higher_timeframe_alignment:"HTF structure alignment",
    liquidity_sweep:"Liquidity sweep",
    mss_or_choch:"MSS / CHoCH",
    fvg:"FVG condition",
    interest_zone:"Price in Interest Zone"
  };
  $("checks").innerHTML = Object.entries(d.confirmations).map(([k,v]) =>
    `<div class="check"><b>${labels[k] || k}</b><span class="${v?'ok':'pending'}">${v?'✓ PASS':'WAIT'}</span></div>`
  ).join("");
}

$("run").onclick = runAnalysis;
runAnalysis();
